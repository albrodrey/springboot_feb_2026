package com.igae.saludo.init.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SaludoController {
	@GetMapping(value="saludar")
	public String saludo() {
		return "Bienvenido a REST";
	}
}
